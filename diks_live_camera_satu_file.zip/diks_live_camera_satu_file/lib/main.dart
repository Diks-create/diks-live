import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:video_player/video_player.dart';

// ======================================================================
// theme.dart
// ======================================================================
const kYellow = Color(0xFFFFC400);
const kRed = Color(0xFFE53935);

ThemeData buildTheme() {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: Colors.black,
    colorScheme: const ColorScheme.dark(
      primary: kYellow,
      secondary: kRed,
      surface: Colors.black,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.black,
      foregroundColor: Colors.white,
      elevation: 0,
    ),
  );
}

// ======================================================================
// live_service.dart
// ======================================================================
/// Satu item di galeri "Diks Live".
class GalleryItem {
  GalleryItem({
    required this.uri,
    required this.path,
    required this.name,
    required this.date,
  });

  final String uri;
  final String path;
  final String name;
  final int date;

  /// File Foto Live diberi awalan LIVE_, foto biasa IMG_.
  bool get isLive => name.startsWith('LIVE_');
}

/// Jembatan ke kode Kotlin (MainActivity.kt).
class Native {
  static const _ch = MethodChannel('diks/native');

  static Future<int> sdkInt() async =>
      (await _ch.invokeMethod<int>('sdkInt')) ?? 26;

  static Future<GalleryItem> saveToGallery(
      String path, String name, String mime) async {
    final r = await _ch.invokeMapMethod<String, dynamic>('saveToGallery', {
      'path': path,
      'name': name,
      'mime': mime,
    });
    return GalleryItem(
      uri: r!['uri'] as String,
      path: (r['path'] as String?) ?? '',
      name: name,
      date: DateTime.now().millisecondsSinceEpoch ~/ 1000,
    );
  }

  static Future<List<GalleryItem>> listGallery() async {
    final r = await _ch.invokeListMethod<Map>('listGallery') ?? [];
    return r
        .map((m) => GalleryItem(
              uri: m['uri'] as String,
              path: m['path'] as String,
              name: m['name'] as String,
              date: (m['date'] as num).toInt(),
            ))
        .toList();
  }

  static Future<bool> deleteItem(String uri) async =>
      (await _ch.invokeMethod<bool>('deleteItem', {'uri': uri})) ?? false;

  /// Gabung + potong segmen video menjadi satu MP4 (1,5 dtk sebelum + 1,5 dtk sesudah).
  static Future<Map<String, dynamic>> buildLiveVideo({
    required List<String> inputs,
    required int shutterIndex,
    required int shutterOffsetMs,
    required int preMs,
    required int postMs,
    required String output,
  }) async {
    final r = await _ch.invokeMapMethod<String, dynamic>('buildLiveVideo', {
      'inputs': inputs,
      'shutterIndex': shutterIndex,
      'offMs': shutterOffsetMs,
      'preMs': preMs,
      'postMs': postMs,
      'output': output,
    });
    return r ?? {};
  }

  static Future<void> extractFrame(
      String video, int timeMs, String output) async {
    await _ch.invokeMethod('extractFrame', {
      'video': video,
      'timeMs': timeMs,
      'output': output,
    });
  }

  /// Mengembalikan "ok" atau "not_installed".
  static Future<String> share(String pathOrUri, String mime, String? pkg) async {
    final r = await _ch.invokeMethod<String>('share', {
      'path': pathOrUri,
      'mime': mime,
      'pkg': pkg,
    });
    return r ?? 'not_installed';
  }
}

class LiveService {
  static const preMs = 1500;
  static const postMs = 1500;

  static String _stamp() {
    final n = DateTime.now();
    String t(int v) => v.toString().padLeft(2, '0');
    return '${n.year}${t(n.month)}${t(n.day)}_${t(n.hour)}${t(n.minute)}${t(n.second)}';
  }

  /// Foto biasa (LIVE OFF): enhance lalu simpan.
  static Future<GalleryItem> saveNormal(Uint8List jpg) async {
    final out = await compute(_process, <Object?>[jpg, null, 0]);
    return _store(out, 'IMG_${_stamp()}.jpg');
  }

  /// Foto Live: potong video, ambil foto diam, enhance, gabung jadi Motion Photo.
  static Future<GalleryItem> saveLive({
    required List<String> segPaths,
    required int curIndex,
    required int offsetMs,
    String? stillPath,
  }) async {
    final tmp = await getTemporaryDirectory();
    final id = DateTime.now().microsecondsSinceEpoch;
    final videoPath = '${tmp.path}/live_$id.mp4';
    final framePath = '${tmp.path}/frame_$id.jpg';

    Uint8List? mp4;
    var presUs = 1500000;
    try {
      final r = await Native.buildLiveVideo(
        inputs: segPaths,
        shutterIndex: curIndex,
        shutterOffsetMs: offsetMs,
        preMs: preMs,
        postMs: postMs,
        output: videoPath,
      );
      mp4 = await File(videoPath).readAsBytes();
      presUs = ((r['shutterMs'] as num?) ?? 1500).toInt() * 1000;
    } catch (_) {
      mp4 = null; // gagal membuat video -> simpan foto biasa saja
    }

    Uint8List? jpg;
    try {
      if (stillPath != null && File(stillPath).existsSync()) {
        jpg = await File(stillPath).readAsBytes();
      } else if (mp4 != null) {
        await Native.extractFrame(videoPath, presUs ~/ 1000, framePath);
        jpg = await File(framePath).readAsBytes();
      }
    } catch (_) {
      jpg = null;
    }

    try {
      if (jpg == null) throw Exception('Gagal mengambil foto');
      final out = await compute(_process, <Object?>[jpg, mp4, presUs]);
      final name = '${mp4 != null ? 'LIVE' : 'IMG'}_${_stamp()}.jpg';
      return await _store(out, name);
    } finally {
      _del(videoPath);
      _del(framePath);
    }
  }

  static Future<GalleryItem> _store(Uint8List bytes, String name) async {
    final tmp = await getTemporaryDirectory();
    final f = File('${tmp.path}/save_${DateTime.now().microsecondsSinceEpoch}.jpg');
    await f.writeAsBytes(bytes, flush: true);
    try {
      return await Native.saveToGallery(f.path, name, 'image/jpeg');
    } finally {
      _del(f.path);
    }
  }

  static void _del(String p) {
    try {
      final f = File(p);
      if (f.existsSync()) f.deleteSync();
    } catch (_) {}
  }

  /// Ambil video MP4 yang tertanam di dalam file Motion Photo (disimpan di cache).
  static Future<String?> extractVideo(String jpgPath) async {
    try {
      final f = File(jpgPath);
      final len = await f.length();
      final raf = await f.open();
      try {
        final head = await raf.read(math.min(8192, len));
        final s = latin1.decode(head, allowInvalid: true);
        final m = RegExp(r'MicroVideoOffset="(\d+)"').firstMatch(s);
        if (m == null) return null;
        final n = int.parse(m.group(1)!);
        if (n <= 0 || n >= len) return null;

        final tmp = await getTemporaryDirectory();
        final name = jpgPath.split('/').last.replaceAll('.jpg', '');
        final out = File('${tmp.path}/v_$name.mp4');
        if (out.existsSync() && out.lengthSync() == n) return out.path;

        await raf.setPosition(len - n);
        final bytes = await raf.read(n);
        await out.writeAsBytes(bytes, flush: true);
        return out.path;
      } finally {
        await raf.close();
      }
    } catch (_) {
      return null;
    }
  }
}

// ---------------------------------------------------------------------------
// Berjalan di isolate terpisah supaya UI tidak lag.
// ---------------------------------------------------------------------------

Uint8List _process(List<Object?> a) {
  final jpg = a[0] as Uint8List;
  final mp4 = a[1] as Uint8List?;
  final presUs = a[2] as int;

  Uint8List out = jpg;
  try {
    var im = img.decodeJpg(jpg);
    if (im != null) {
      im = img.bakeOrientation(im);
      // 1) bersihkan noise ringan
      im = img.gaussianBlur(im, radius: 1);
      // 2) naikkan ketajaman (sharpen)
      im = img.convolution(
        im,
        filter: const <num>[0, -1, 0, -1, 5, -1, 0, -1, 0],
        div: 1,
        amount: 0.9,
      );
      // 3) brightness naik sedikit + kontras/warna tipis
      im = img.adjustColor(im,
          brightness: 1.06, contrast: 1.05, saturation: 1.05);
      out = Uint8List.fromList(img.encodeJpg(im, quality: 92));
    }
  } catch (_) {
    out = jpg;
  }

  if (mp4 == null) return out;
  return _packMotionPhoto(out, mp4, presUs);
}

/// Format Motion Photo (Google): JPG + XMP + MP4 ditempel di akhir file.
Uint8List _packMotionPhoto(Uint8List jpg, Uint8List mp4, int presUs) {
  final xmp = '''<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="Diks Live Camera">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about=""
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    xmlns:Container="http://ns.google.com/photos/1.0/container/"
    xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
    GCamera:MotionPhoto="1"
    GCamera:MotionPhotoVersion="1"
    GCamera:MotionPhotoPresentationTimestampUs="$presUs"
    GCamera:MicroVideo="1"
    GCamera:MicroVideoVersion="1"
    GCamera:MicroVideoOffset="${mp4.length}"
    GCamera:MicroVideoPresentationTimestampUs="$presUs">
   <Container:Directory>
    <rdf:Seq>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary" Item:Length="0" Item:Padding="0"/>
     </rdf:li>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="${mp4.length}" Item:Padding="0"/>
     </rdf:li>
    </rdf:Seq>
   </Container:Directory>
  </rdf:Description>
 </rdf:RDF>
</x:xmpmeta>''';

  final header = ascii.encode('http://ns.adobe.com/xap/1.0/\x00');
  final xmpBytes = utf8.encode(xmp);
  final segLen = 2 + header.length + xmpBytes.length;

  final b = BytesBuilder(copy: false);
  b.add(const [0xFF, 0xD8]); // SOI
  b.add([0xFF, 0xE1, (segLen >> 8) & 0xFF, segLen & 0xFF]); // APP1
  b.add(header);
  b.add(xmpBytes);
  b.add(Uint8List.sublistView(jpg, 2)); // sisa JPG
  b.add(mp4); // video di akhir file
  return b.toBytes();
}

// ======================================================================
// gallery_page.dart
// ======================================================================
class GalleryPage extends StatefulWidget {
  const GalleryPage({super.key});

  @override
  State<GalleryPage> createState() => _GalleryPageState();
}

class _GalleryPageState extends State<GalleryPage> {
  List<GalleryItem>? _items;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Native.listGallery();
      if (mounted) setState(() => _items = l);
    } catch (_) {
      if (mounted) setState(() => _items = []);
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = _items;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'GALERI LIVE',
          style: TextStyle(
              color: kYellow, fontWeight: FontWeight.w900, letterSpacing: 1.5),
        ),
      ),
      body: items == null
          ? const Center(child: CircularProgressIndicator(color: kYellow))
          : items.isEmpty
              ? const Center(
                  child: Text('Belum ada foto',
                      style: TextStyle(color: Colors.white54)))
              : GridView.builder(
                  padding: const EdgeInsets.all(4),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 3,
                    crossAxisSpacing: 3,
                  ),
                  itemCount: items.length,
                  itemBuilder: (_, i) {
                    final it = items[i];
                    return GestureDetector(
                      onTap: () async {
                        await Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => ViewerPage(items: items, index: i),
                        ));
                        _load();
                      },
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.file(
                            File(it.path),
                            fit: BoxFit.cover,
                            cacheWidth: 300, // hemat RAM
                            errorBuilder: (_, __, ___) => Container(
                              color: const Color(0xFF1A1A1A),
                              child: const Icon(Icons.broken_image,
                                  color: Colors.white24),
                            ),
                          ),
                          if (it.isLive)
                            const Positioned(
                              top: 4,
                              left: 4,
                              child: _LiveTag(),
                            ),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}

class _LiveTag extends StatelessWidget {
  const _LiveTag();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
      decoration: BoxDecoration(
        color: kYellow,
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.motion_photos_on, size: 11, color: Colors.black),
          SizedBox(width: 2),
          Text('LIVE',
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 9,
                  fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

// ===========================================================================
// Penampil foto: tekan & tahan = putar video 3 detik, lepas = kembali foto diam
// ===========================================================================

class ViewerPage extends StatefulWidget {
  const ViewerPage({super.key, required this.items, required this.index});
  final List<GalleryItem> items;
  final int index;

  @override
  State<ViewerPage> createState() => _ViewerPageState();
}

class _ViewerPageState extends State<ViewerPage> {
  late final PageController _pc;
  late List<GalleryItem> _items;
  int _i = 0;
  int _token = 0;
  VideoPlayerController? _vc;
  bool _ready = false;
  bool _playing = false;

  @override
  void initState() {
    super.initState();
    _items = List.of(widget.items);
    _i = widget.index;
    _pc = PageController(initialPage: _i);
    _prepare();
  }

  @override
  void dispose() {
    _token++;
    _vc?.dispose();
    _pc.dispose();
    super.dispose();
  }

  Future<void> _prepare() async {
    final token = ++_token;
    final old = _vc;
    _vc = null;
    _ready = false;
    _playing = false;
    if (mounted) setState(() {});
    old?.removeListener(_tick);
    await old?.dispose();

    if (_items.isEmpty) return;
    final it = _items[_i];
    if (!it.isLive) return;

    final path = await LiveService.extractVideo(it.path);
    if (path == null || token != _token || !mounted) return;

    final vc = VideoPlayerController.file(File(path));
    try {
      await vc.initialize();
    } catch (_) {
      await vc.dispose();
      return;
    }
    if (token != _token || !mounted) {
      await vc.dispose();
      return;
    }
    vc.setLooping(false);
    vc.addListener(_tick);
    setState(() {
      _vc = vc;
      _ready = true;
    });
  }

  void _tick() {
    final v = _vc;
    if (v == null || !_playing) return;
    final d = v.value.duration;
    if (d > Duration.zero && v.value.position >= d) _stopPlay();
  }

  Future<void> _startPlay() async {
    final v = _vc;
    if (v == null || !_ready || _playing) return;
    HapticFeedback.lightImpact();
    setState(() => _playing = true);
    await v.seekTo(Duration.zero);
    await v.play();
  }

  Future<void> _stopPlay() async {
    final v = _vc;
    if (v == null) return;
    if (mounted) setState(() => _playing = false);
    await v.pause();
    await v.seekTo(Duration.zero);
  }

  Future<void> _delete() async {
    final it = _items[_i];
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF141414),
        title: const Text('Hapus foto?'),
        content: const Text('Foto ini akan dihapus dari galeri HP.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Hapus', style: TextStyle(color: kRed))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Native.deleteItem(it.uri);
    } catch (_) {}
    if (!mounted) return;
    setState(() => _items.removeAt(_i));
    if (_items.isEmpty) {
      Navigator.of(context).pop();
      return;
    }
    if (_i >= _items.length) _i = _items.length - 1;
    _prepare();
  }

  @override
  Widget build(BuildContext context) {
    final cur = _items.isEmpty ? null : _items[_i];
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.black38,
        title: cur != null && cur.isLive ? const _LiveTag() : null,
        actions: [
          IconButton(
            icon: const Icon(Icons.share_rounded, color: kYellow),
            onPressed: cur == null ? null : () => showShareSheet(context, cur),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded, color: kRed),
            onPressed: cur == null ? null : _delete,
          ),
        ],
      ),
      body: PageView.builder(
        controller: _pc,
        itemCount: _items.length,
        onPageChanged: (i) {
          _i = i;
          _prepare();
        },
        itemBuilder: (_, i) {
          final it = _items[i];
          final isCur = i == _i;
          final canPlay = it.isLive && isCur;
          return GestureDetector(
            onLongPressStart: canPlay ? (_) => _startPlay() : null,
            onLongPressEnd: canPlay ? (_) => _stopPlay() : null,
            onLongPressCancel: canPlay ? _stopPlay : null,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.file(
                  File(it.path),
                  fit: BoxFit.contain,
                  cacheWidth: 1080,
                  errorBuilder: (_, __, ___) => const Center(
                      child: Icon(Icons.broken_image, color: Colors.white24)),
                ),
                if (isCur && _playing && _vc != null) ...[
                  Container(color: Colors.black),
                  Center(
                    child: AspectRatio(
                      aspectRatio: _vc!.value.aspectRatio,
                      child: VideoPlayer(_vc!),
                    ),
                  ),
                ],
                if (canPlay && !_playing)
                  Positioned(
                    bottom: 40,
                    left: 0,
                    right: 0,
                    child: Center(
                      child: Text(
                        _ready
                            ? 'Tekan & tahan untuk memutar'
                            : 'Menyiapkan video...',
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 13),
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ===========================================================================
// Share ke WhatsApp / TikTok / Instagram
// ===========================================================================

Future<void> showShareSheet(BuildContext context, GalleryItem it) async {
  var asVideo = it.isLive;
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: const Color(0xFF141414),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSheet) {
        Future<void> go(List<String?> pkgs) async {
          Navigator.pop(ctx);
          var path = it.uri;
          var mime = 'image/jpeg';
          if (it.isLive && asVideo) {
            final v = await LiveService.extractVideo(it.path);
            if (v != null) {
              path = v;
              mime = 'video/mp4';
            }
          }
          var r = 'not_installed';
          for (final p in pkgs) {
            r = await Native.share(path, mime, p);
            if (r == 'ok') break;
          }
          if (r != 'ok' && context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('Aplikasi belum terpasang. Coba tombol "Lainnya".'),
            ));
          }
        }

        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('BAGIKAN',
                    style: TextStyle(
                        color: kYellow,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2)),
                if (it.isLive) ...[
                  const SizedBox(height: 14),
                  SegmentedButton<bool>(
                    style: SegmentedButton.styleFrom(
                      selectedBackgroundColor: kYellow,
                      selectedForegroundColor: Colors.black,
                    ),
                    segments: const [
                      ButtonSegment(value: true, label: Text('Video 3 dtk')),
                      ButtonSegment(value: false, label: Text('Foto')),
                    ],
                    selected: {asVideo},
                    onSelectionChanged: (s) =>
                        setSheet(() => asVideo = s.first),
                  ),
                ],
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _ShareBtn(Icons.chat_rounded, 'WhatsApp',
                        const Color(0xFF25D366), () => go(['com.whatsapp'])),
                    _ShareBtn(
                        Icons.music_note_rounded,
                        'TikTok',
                        const Color(0xFFFE2C55),
                        () => go([
                              'com.zhiliaoapp.musically',
                              'com.ss.android.ugc.trill'
                            ])),
                    _ShareBtn(Icons.camera_alt_rounded, 'Instagram',
                        const Color(0xFFE1306C), () => go(['com.instagram.android'])),
                    _ShareBtn(Icons.share_rounded, 'Lainnya', kYellow,
                        () => go([null])),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    ),
  );
}

class _ShareBtn extends StatelessWidget {
  const _ShareBtn(this.icon, this.label, this.color, this.onTap);
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color),
            child: Icon(icon,
                color: color == kYellow ? Colors.black : Colors.white),
          ),
          const SizedBox(height: 6),
          Text(label,
              style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ],
      ),
    );
  }
}

// ======================================================================
// camera_page.dart
// ======================================================================
/// Ganti ke ResolutionPreset.veryHigh (1080p) kalau HP kuat dan ingin lebih tajam.
const kResolution = ResolutionPreset.high;

/// Panjang tiap segmen rekaman berputar (buffer pre-roll).
const kSegment = Duration(milliseconds: 1500);

class _Seg {
  _Seg(this.path);
  final String path;
}

class _Capture {
  _Capture({required this.prev, required this.shutterAt, required this.curStart});
  final _Seg? prev; // segmen 1,5 dtk sebelum shutter
  final DateTime shutterAt;
  final DateTime? curStart; // awal segmen yang sedang berjalan saat shutter
  _Seg? cur; // segmen yang memuat saat shutter
  _Seg? next; // segmen sesudahnya
  String? photoPath;
  int offMs = 0;
  final Completer<bool> done = Completer<bool>();
}

class CameraPage extends StatefulWidget {
  const CameraPage({super.key, required this.cameras});
  final List<CameraDescription> cameras;

  @override
  State<CameraPage> createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> with WidgetsBindingObserver {
  CameraController? _cam;
  int _camIndex = 0;
  bool _ready = false;
  bool _initing = false;
  bool _wanted = true; // false saat sedang di halaman galeri
  bool _switching = false;

  bool _live = true;
  bool _flash = false;
  bool _shooting = false;
  bool _blink = false;
  int _saving = 0;

  double _zoom = 1, _minZoom = 1, _maxZoom = 1;
  String? _thumb;

  // --- buffer segmen untuk Foto Live ---
  _Seg? _lastSeg;
  _Capture? _cap;
  DateTime? _recStart;
  bool _loopRun = false;
  Future<void>? _loop;
  Completer<void>? _stopSig;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final back = widget.cameras
        .indexWhere((c) => c.lensDirection == CameraLensDirection.back);
    _camIndex = back >= 0 ? back : 0;
    _initCamera();
    _loadThumb();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _loopRun = false;
    if (_stopSig != null && !_stopSig!.isCompleted) _stopSig!.complete();
    _cam?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      _disposeCamera();
    } else if (state == AppLifecycleState.resumed && _wanted) {
      _initCamera();
    }
  }

  // ------------------------------------------------------------------ kamera

  Future<void> _initCamera() async {
    if (_initing) return;
    _initing = true;
    try {
      await _disposeCamera();
      if (!mounted) return;
      final c = CameraController(
        widget.cameras[_camIndex],
        kResolution,
        enableAudio: true,
      );
      _cam = c;
      await c.initialize();
      await c.lockCaptureOrientation(DeviceOrientation.portraitUp);
      _minZoom = await c.getMinZoomLevel();
      _maxZoom = (await c.getMaxZoomLevel()).clamp(_minZoom, 8.0);
      _zoom = _minZoom;
      await _applyFlash();
      if (!mounted) return;
      setState(() => _ready = true);
      if (_live) _startLoop();
    } catch (e) {
      _toast('Kamera gagal dibuka: $e');
    } finally {
      _initing = false;
    }
  }

  Future<void> _disposeCamera() async {
    _loopRun = false;
    if (_stopSig != null && !_stopSig!.isCompleted) _stopSig!.complete();
    final cap = _cap;
    _cap = null;
    if (cap != null && !cap.done.isCompleted) cap.done.complete(false);
    try {
      await _loop;
    } catch (_) {}
    _loop = null;
    final c = _cam;
    _cam = null;
    if (mounted) setState(() => _ready = false);
    try {
      await c?.dispose();
    } catch (_) {}
    _delete(_lastSeg?.path);
    _lastSeg = null;
    _recStart = null;
  }

  Future<void> _switchCamera() async {
    if (_shooting || _switching || widget.cameras.length < 2) return;
    _switching = true;
    final cur = widget.cameras[_camIndex].lensDirection;
    final want = cur == CameraLensDirection.back
        ? CameraLensDirection.front
        : CameraLensDirection.back;
    final idx = widget.cameras.indexWhere((c) => c.lensDirection == want);
    if (idx >= 0) {
      _camIndex = idx;
      await _initCamera();
    }
    _switching = false;
  }

  Future<void> _applyFlash() async {
    final c = _cam;
    if (c == null) return;
    try {
      await c.setFlashMode(!_flash
          ? FlashMode.off
          : (_live ? FlashMode.torch : FlashMode.always));
    } catch (_) {}
  }

  Future<void> _toggleFlash() async {
    setState(() => _flash = !_flash);
    await _applyFlash();
  }

  Future<void> _setZoom(double v) async {
    setState(() => _zoom = v);
    try {
      await _cam?.setZoomLevel(v);
    } catch (_) {}
  }

  // -------------------------------------------------------- loop buffer segmen

  void _startLoop() {
    if (_loopRun) return;
    _loopRun = true;
    _stopSig = Completer<void>();
    _loop = _runLoop(_stopSig!);
  }

  Future<void> _runLoop(Completer<void> sig) async {
    while (_loopRun && _live) {
      final c = _cam;
      if (c == null || !c.value.isInitialized) break;
      try {
        await c.startVideoRecording();
        _recStart = DateTime.now();
        final aborted = await Future.any<bool>([
          Future.delayed(kSegment).then((_) => false),
          sig.future.then((_) => true),
        ]);
        final f = await c.stopVideoRecording();
        if (aborted) {
          _recStart = null;
          _delete(f.path);
          break;
        }
        _onSegment(_Seg(f.path));
      } catch (_) {
        _recStart = null;
        try {
          if (c.value.isRecordingVideo) {
            final f = await c.stopVideoRecording();
            _delete(f.path);
          }
        } catch (_) {}
        await Future.delayed(const Duration(milliseconds: 400));
      }
    }
    _loopRun = false;
  }

  void _onSegment(_Seg seg) {
    _recStart = null;
    final cap = _cap;
    if (cap == null) {
      _delete(_lastSeg?.path); // buang segmen lama, simpan yang terbaru saja
      _lastSeg = seg;
      return;
    }
    if (cap.cur == null) {
      cap.cur = seg;
      final st = cap.curStart;
      cap.offMs =
          st == null ? 0 : cap.shutterAt.difference(st).inMilliseconds.clamp(0, 5000);
    } else {
      cap.next = seg;
      _cap = null;
      if (!cap.done.isCompleted) cap.done.complete(true);
    }
  }

  Future<void> _toggleLive() async {
    if (_shooting || _switching || !_ready) return;
    setState(() => _live = !_live);
    HapticFeedback.selectionClick();
    if (_live) {
      await _applyFlash();
      _startLoop();
    } else {
      _loopRun = false;
      if (_stopSig != null && !_stopSig!.isCompleted) _stopSig!.complete();
      try {
        await _loop;
      } catch (_) {}
      _delete(_lastSeg?.path);
      _lastSeg = null;
      await _applyFlash();
    }
  }

  // ----------------------------------------------------------------- shutter

  Future<void> _onShutter() async {
    final c = _cam;
    if (c == null || !_ready || _shooting || _switching || _initing) return;
    HapticFeedback.mediumImpact();
    if (_live && _loopRun) {
      await _shootLive(c);
    } else {
      await _shootNormal(c);
    }
  }

  void _doBlink() {
    setState(() => _blink = true);
    Future.delayed(const Duration(milliseconds: 90), () {
      if (mounted) setState(() => _blink = false);
    });
  }

  Future<void> _shootNormal(CameraController c) async {
    setState(() => _shooting = true);
    try {
      final x = await c.takePicture();
      _doBlink();
      final bytes = await x.readAsBytes();
      _delete(x.path);
      _saveNormalInBackground(bytes);
    } catch (e) {
      _toast('Gagal mengambil foto: $e');
    } finally {
      if (mounted) setState(() => _shooting = false);
    }
  }

  Future<void> _saveNormalInBackground(Uint8List bytes) async {
    _setSaving(1);
    try {
      final item = await LiveService.saveNormal(bytes);
      _newItem(item);
    } catch (e) {
      _toast('Gagal menyimpan: $e');
    } finally {
      _setSaving(-1);
    }
  }

  Future<void> _shootLive(CameraController c) async {
    setState(() => _shooting = true);
    final cap = _Capture(
      prev: _lastSeg,
      shutterAt: DateTime.now(),
      curStart: _recStart,
    );
    _lastSeg = null;
    _cap = cap;
    _doBlink();
    _toast('Tahan sebentar... merekam Foto Live', short: true);

    // Foto diam resolusi penuh (kalau HP mengizinkan saat merekam).
    try {
      final x = await c.takePicture().timeout(const Duration(seconds: 2));
      cap.photoPath = x.path;
    } catch (_) {}

    var ok = false;
    try {
      ok = await cap.done.future
          .timeout(const Duration(seconds: 8), onTimeout: () => false);
    } catch (_) {}

    if (identical(_cap, cap)) _cap = null;
    if (mounted) setState(() => _shooting = false);

    if (ok && cap.cur != null && cap.next != null) {
      _processLive(cap);
    } else {
      _fallbackStill(cap);
    }
  }

  Future<void> _processLive(_Capture cap) async {
    _setSaving(1);
    final segs = <_Seg>[if (cap.prev != null) cap.prev!, cap.cur!, cap.next!];
    try {
      final item = await LiveService.saveLive(
        segPaths: segs.map((s) => s.path).toList(),
        curIndex: cap.prev != null ? 1 : 0,
        offsetMs: cap.offMs,
        stillPath: cap.photoPath,
      );
      _newItem(item);
    } catch (e) {
      _toast('Gagal menyimpan Foto Live: $e');
    } finally {
      for (final s in segs) {
        _delete(s.path);
      }
      _delete(cap.photoPath);
      _setSaving(-1);
    }
  }

  /// Kalau perekaman Live gagal, simpan setidaknya foto biasanya.
  Future<void> _fallbackStill(_Capture cap) async {
    final p = cap.photoPath;
    try {
      if (p != null && File(p).existsSync()) {
        _saveNormalInBackground(await File(p).readAsBytes());
        _toast('Live gagal, disimpan sebagai foto biasa');
      } else {
        _toast('Foto Live gagal, coba lagi');
      }
    } catch (_) {}
    for (final s in [cap.prev, cap.cur, cap.next]) {
      _delete(s?.path);
    }
    _delete(p);
  }

  // ---------------------------------------------------------------- galeri

  Future<void> _loadThumb() async {
    try {
      final l = await Native.listGallery();
      if (mounted) setState(() => _thumb = l.isEmpty ? null : l.first.path);
    } catch (_) {}
  }

  void _newItem(GalleryItem item) {
    if (mounted && item.path.isNotEmpty) setState(() => _thumb = item.path);
  }

  Future<void> _openGallery() async {
    if (_shooting) return;
    _wanted = false;
    await _disposeCamera(); // hemat RAM saat di galeri
    if (!mounted) return;
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const GalleryPage()));
    if (!mounted) return;
    _wanted = true;
    await _loadThumb();
    await _initCamera();
  }

  // ------------------------------------------------------------------ util

  void _setSaving(int d) {
    if (mounted) setState(() => _saving += d);
  }

  void _delete(String? p) {
    if (p == null) return;
    try {
      final f = File(p);
      if (f.existsSync()) f.deleteSync();
    } catch (_) {}
  }

  void _toast(String msg, {bool short = false}) {
    if (!mounted) return;
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(
      content: Text(msg),
      duration: Duration(milliseconds: short ? 1400 : 2600),
      behavior: SnackBarBehavior.floating,
      backgroundColor: const Color(0xFF222222),
    ));
  }

  // -------------------------------------------------------------------- UI

  Widget _preview(CameraController c, Size size) {
    var scale = size.aspectRatio * c.value.aspectRatio;
    if (scale < 1) scale = 1 / scale;
    return Transform.scale(
      scale: scale,
      child: Center(child: CameraPreview(c)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final c = _cam;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_ready && c != null && c.value.isInitialized)
            ClipRect(child: _preview(c, size))
          else
            const Center(child: CircularProgressIndicator(color: kYellow)),
          IgnorePointer(
            child: AnimatedOpacity(
              opacity: _blink ? 0.75 : 0,
              duration: const Duration(milliseconds: 80),
              child: Container(color: Colors.white),
            ),
          ),
          Positioned(top: 0, left: 0, right: 0, child: _topBar()),
          Positioned(bottom: 0, left: 0, right: 0, child: _bottomBar()),
        ],
      ),
    );
  }

  Widget _topBar() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xCC000000), Colors.transparent],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _roundBtn(
                _flash ? Icons.flash_on_rounded : Icons.flash_off_rounded,
                _toggleFlash,
                color: _flash ? kYellow : Colors.white,
              ),
              _liveBadge(),
              SizedBox(
                width: 48,
                child: _saving > 0
                    ? const Center(
                        child: SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                              strokeWidth: 3, color: kYellow),
                        ),
                      )
                    : null,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _liveBadge() {
    return GestureDetector(
      onTap: _toggleLive,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _live ? kYellow : Colors.black54,
          border: Border.all(color: _live ? kRed : Colors.white38, width: 3),
        ),
        alignment: Alignment.center,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              _live ? Icons.motion_photos_on : Icons.motion_photos_off,
              size: 18,
              color: _live ? Colors.black : Colors.white54,
            ),
            Text(
              'LIVE',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w900,
                color: _live ? Colors.black : Colors.white54,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _roundBtn(IconData icon, VoidCallback onTap,
      {Color color = Colors.white}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 48,
        height: 48,
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: Color(0x66000000),
        ),
        child: Icon(icon, color: color, size: 26),
      ),
    );
  }

  Widget _bottomBar() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.transparent, Color(0xDD000000), Colors.black],
        ),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 32, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _zoomRow(),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [_galleryBtn(), _shutter(), _switchBtn()],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _zoomRow() {
    final enabled = _ready && _maxZoom > _minZoom;
    return Row(
      children: [
        const Icon(Icons.zoom_out_rounded, color: Colors.white54, size: 20),
        Expanded(
          child: SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: kYellow,
              inactiveTrackColor: Colors.white24,
              thumbColor: kRed,
              overlayColor: kRed.withOpacity(0.2),
              trackHeight: 3,
            ),
            child: Slider(
              value: _zoom.clamp(_minZoom, enabled ? _maxZoom : _minZoom + 0.001),
              min: _minZoom,
              max: enabled ? _maxZoom : _minZoom + 0.001,
              onChanged: enabled ? _setZoom : null,
            ),
          ),
        ),
        const Icon(Icons.zoom_in_rounded, color: Colors.white54, size: 20),
        const SizedBox(width: 8),
        SizedBox(
          width: 38,
          child: Text('${_zoom.toStringAsFixed(1)}x',
              style: const TextStyle(
                  color: kYellow, fontSize: 12, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }

  Widget _shutter() {
    return GestureDetector(
      onTap: _onShutter,
      child: SizedBox(
        width: 88,
        height: 88,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 88,
              height: 88,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                    color: _live ? kYellow : Colors.white54, width: 4),
              ),
            ),
            AnimatedContainer(
              duration: const Duration(milliseconds: 120),
              width: _shooting ? 56 : 70,
              height: _shooting ? 56 : 70,
              decoration: const BoxDecoration(
                  color: Colors.white, shape: BoxShape.circle),
            ),
            if (_shooting && _live)
              const SizedBox(
                width: 88,
                height: 88,
                child: CircularProgressIndicator(strokeWidth: 4, color: kRed),
              ),
          ],
        ),
      ),
    );
  }

  Widget _galleryBtn() {
    return GestureDetector(
      onTap: _openGallery,
      child: Container(
        width: 54,
        height: 54,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF1A1A1A),
          border: Border.all(color: kYellow, width: 2),
        ),
        child: _thumb == null
            ? const Icon(Icons.photo_library_rounded, color: kYellow)
            : Image.file(
                File(_thumb!),
                fit: BoxFit.cover,
                cacheWidth: 150,
                errorBuilder: (_, __, ___) =>
                    const Icon(Icons.photo_library_rounded, color: kYellow),
              ),
      ),
    );
  }

  Widget _switchBtn() {
    return GestureDetector(
      onTap: _switchCamera,
      child: Container(
        width: 54,
        height: 54,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF1A1A1A),
          border: Border.all(color: kRed, width: 2),
        ),
        child: const Icon(Icons.cameraswitch_rounded, color: Colors.white),
      ),
    );
  }
}

// ======================================================================
// main.dart
// ======================================================================
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.black,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const DiksApp());
}

class DiksApp extends StatelessWidget {
  const DiksApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Diks Live Camera',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const Boot(),
    );
  }
}

enum _BootState { loading, denied, noCamera, ready }

class Boot extends StatefulWidget {
  const Boot({super.key});

  @override
  State<Boot> createState() => _BootState2();
}

class _BootState2 extends State<Boot> {
  _BootState _state = _BootState.loading;
  bool _permanent = false;
  List<CameraDescription> _cameras = [];

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    setState(() => _state = _BootState.loading);
    final sdk = await Native.sdkInt();
    final perms = <Permission>[
      Permission.camera,
      Permission.microphone,
      if (sdk < 29) Permission.storage, // Android 8-9 butuh izin penyimpanan
    ];
    final res = await perms.request();
    final ok = perms.every((p) => res[p]?.isGranted ?? false);
    if (!ok) {
      _permanent = perms.any((p) => res[p]?.isPermanentlyDenied ?? false);
      if (mounted) setState(() => _state = _BootState.denied);
      return;
    }
    try {
      _cameras = await availableCameras();
    } catch (_) {
      _cameras = [];
    }
    if (!mounted) return;
    setState(() => _state = _cameras.isEmpty ? _BootState.noCamera : _BootState.ready);
  }

  @override
  Widget build(BuildContext context) {
    switch (_state) {
      case _BootState.ready:
        return CameraPage(cameras: _cameras);
      case _BootState.loading:
        return const Scaffold(
          body: Center(child: CircularProgressIndicator(color: kYellow)),
        );
      case _BootState.noCamera:
        return const Scaffold(
          body: Center(
            child: Text('Kamera tidak ditemukan di perangkat ini.',
                style: TextStyle(color: Colors.white70)),
          ),
        );
      case _BootState.denied:
        return Scaffold(
          body: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: kYellow,
                    border: Border.all(color: kRed, width: 4),
                  ),
                  alignment: Alignment.center,
                  child: const Text('LIVE',
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w900,
                          fontSize: 22)),
                ),
                const SizedBox(height: 24),
                const Text('DIKS LIVE CAMERA',
                    style: TextStyle(
                        color: kYellow,
                        fontWeight: FontWeight.w900,
                        fontSize: 22,
                        letterSpacing: 2)),
                const SizedBox(height: 12),
                const Text(
                  'Aplikasi butuh izin Kamera, Mikrofon, dan Penyimpanan untuk merekam dan menyimpan Foto Live.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70, height: 1.4),
                ),
                const SizedBox(height: 28),
                FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: kYellow,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                  ),
                  onPressed: _permanent ? openAppSettings : _start,
                  child: Text(_permanent ? 'BUKA PENGATURAN' : 'BERI IZIN',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
              ],
            ),
          ),
        );
    }
  }
}
