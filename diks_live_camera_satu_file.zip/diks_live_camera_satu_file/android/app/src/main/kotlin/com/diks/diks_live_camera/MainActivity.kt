package com.diks.diks_live_camera

import android.content.ClipData
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.nio.ByteBuffer
import kotlin.concurrent.thread

class MainActivity : FlutterActivity() {

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "diks/native")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "sdkInt" -> result.success(Build.VERSION.SDK_INT)

                    "saveToGallery" -> bg(result) {
                        saveToGallery(
                            call.argument<String>("path")!!,
                            call.argument<String>("name")!!,
                            call.argument<String>("mime")!!
                        )
                    }

                    "listGallery" -> bg(result) { listGallery() }

                    "deleteItem" -> bg(result) {
                        contentResolver.delete(Uri.parse(call.argument<String>("uri")!!), null, null) > 0
                    }

                    "buildLiveVideo" -> bg(result) {
                        buildLiveVideo(
                            call.argument<List<String>>("inputs")!!,
                            call.argument<Number>("shutterIndex")!!.toInt(),
                            call.argument<Number>("offMs")!!.toLong(),
                            call.argument<Number>("preMs")!!.toLong(),
                            call.argument<Number>("postMs")!!.toLong(),
                            call.argument<String>("output")!!
                        )
                    }

                    "extractFrame" -> bg(result) {
                        extractFrame(
                            call.argument<String>("video")!!,
                            call.argument<Number>("timeMs")!!.toLong(),
                            call.argument<String>("output")!!
                        )
                        true
                    }

                    "share" -> result.success(
                        share(
                            call.argument<String>("path")!!,
                            call.argument<String>("mime")!!,
                            call.argument<String>("pkg")
                        )
                    )

                    else -> result.notImplemented()
                }
            }
    }

    /** Jalankan kerja berat di thread lain agar UI tidak lag. */
    private fun bg(result: MethodChannel.Result, block: () -> Any?) {
        thread {
            try {
                val r = block()
                runOnUiThread { result.success(r) }
            } catch (e: Exception) {
                runOnUiThread { result.error("ERR", e.message, null) }
            }
        }
    }

    // ------------------------------------------------------------------
    // Simpan ke galeri: Pictures/Diks Live
    // ------------------------------------------------------------------
    private fun saveToGallery(path: String, name: String, mime: String): Map<String, String> {
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Diks Live")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "Diks Live"
                )
                dir.mkdirs()
                @Suppress("DEPRECATION")
                put(MediaStore.Images.Media.DATA, File(dir, name).absolutePath)
            }
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw Exception("Gagal membuat file di galeri")

        resolver.openOutputStream(uri)!!.use { out ->
            File(path).inputStream().use { it.copyTo(out) }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        }

        var realPath = ""
        @Suppress("DEPRECATION")
        resolver.query(uri, arrayOf(MediaStore.Images.Media.DATA), null, null, null)?.use { c ->
            if (c.moveToFirst()) realPath = c.getString(0) ?: ""
        }
        return mapOf("uri" to uri.toString(), "path" to realPath)
    }

    private fun listGallery(): List<Map<String, Any?>> {
        val out = ArrayList<Map<String, Any?>>()
        @Suppress("DEPRECATION")
        val cols = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATA,
            MediaStore.Images.Media.DATE_ADDED
        )
        @Suppress("DEPRECATION")
        contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            cols,
            "${MediaStore.Images.Media.DATA} LIKE ?",
            arrayOf("%/Pictures/Diks Live/%"),
            "${MediaStore.Images.Media.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out.add(
                    mapOf(
                        "uri" to ContentUris.withAppendedId(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id
                        ).toString(),
                        "name" to (c.getString(1) ?: ""),
                        "path" to (c.getString(2) ?: ""),
                        "date" to c.getLong(3)
                    )
                )
            }
        }
        return out
    }

    // ------------------------------------------------------------------
    // Gabung segmen video + potong jadi jendela [shutter - pre, shutter + post]
    // Tanpa re-encode (MediaExtractor + MediaMuxer) -> cepat dan hemat RAM.
    // ------------------------------------------------------------------
    private fun buildLiveVideo(
        inputs: List<String>,
        shutterIdx: Int,
        shutterOffMs: Long,
        preMs: Long,
        postMs: Long,
        outPath: String
    ): Map<String, Any> {
        // 1) durasi tiap segmen + rotasi
        val durUs = LongArray(inputs.size)
        var rotation = 0
        for ((i, p) in inputs.withIndex()) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(p)
                durUs[i] = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L) * 1000L
                if (i == 0) {
                    rotation = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                        ?.toIntOrNull() ?: 0
                }
            } finally {
                r.release()
            }
        }
        val total = durUs.sum()
        var shutterUs = 0L
        for (i in 0 until shutterIdx) shutterUs += durUs[i]
        shutterUs += shutterOffMs * 1000L
        shutterUs = shutterUs.coerceIn(0L, total)
        val startUs = (shutterUs - preMs * 1000L).coerceAtLeast(0L)
        val endUs = (shutterUs + postMs * 1000L).coerceAtMost(total)

        // 2) siapkan muxer dengan format dari segmen pertama
        File(outPath).delete()
        val muxer = MediaMuxer(outPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        muxer.setOrientationHint(rotation)
        var vOut = -1
        var aOut = -1
        val first = MediaExtractor()
        try {
            first.setDataSource(inputs[0])
            for (t in 0 until first.trackCount) {
                val f = first.getTrackFormat(t)
                val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("video/") && vOut < 0) vOut = muxer.addTrack(f)
                else if (m.startsWith("audio/") && aOut < 0) aOut = muxer.addTrack(f)
            }
        } finally {
            first.release()
        }
        if (vOut < 0) {
            muxer.release()
            throw Exception("Segmen tidak punya track video")
        }
        muxer.start()

        // 3) salin sample
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        var base = 0L
        var originUs = -1L
        var written = 0

        for ((i, p) in inputs.withIndex()) {
            val fileEnd = base + durUs[i]
            if (fileEnd > startUs && base < endUs) {
                for (isVideo in listOf(true, false)) {
                    val outTrack = if (isVideo) vOut else aOut
                    if (outTrack < 0) continue
                    val ex = MediaExtractor()
                    try {
                        ex.setDataSource(p)
                        var tr = -1
                        for (t in 0 until ex.trackCount) {
                            val m = ex.getTrackFormat(t).getString(MediaFormat.KEY_MIME) ?: continue
                            if (m.startsWith(if (isVideo) "video/" else "audio/")) {
                                tr = t
                                break
                            }
                        }
                        if (tr < 0) continue
                        ex.selectTrack(tr)
                        val localStart = (startUs - base).coerceAtLeast(0L)
                        if (localStart > 0) {
                            ex.seekTo(
                                localStart,
                                if (isVideo) MediaExtractor.SEEK_TO_PREVIOUS_SYNC
                                else MediaExtractor.SEEK_TO_CLOSEST_SYNC
                            )
                        }
                        while (true) {
                            buf.clear()
                            val size = ex.readSampleData(buf, 0)
                            if (size < 0) break
                            val global = base + ex.sampleTime
                            if (global >= endUs) break
                            if (isVideo && originUs < 0) originUs = global
                            if (originUs < 0 || global < originUs) {
                                ex.advance()
                                continue
                            }
                            info.set(0, size, global - originUs, ex.sampleFlags)
                            muxer.writeSampleData(outTrack, buf, info)
                            if (isVideo) written++
                            ex.advance()
                        }
                    } finally {
                        ex.release()
                    }
                }
            }
            base += durUs[i]
        }

        try {
            muxer.stop()
        } catch (e: Exception) {
            muxer.release()
            throw Exception("Gagal membuat video Live")
        }
        muxer.release()
        if (written == 0 || originUs < 0) throw Exception("Video kosong")

        val shutterInOutMs = ((shutterUs - originUs).coerceAtLeast(0L)) / 1000L
        return mapOf(
            "shutterMs" to shutterInOutMs,
            "durationMs" to ((endUs - originUs) / 1000L)
        )
    }

    /** Ambil satu frame dari video sebagai JPG (cadangan kalau takePicture gagal saat merekam). */
    private fun extractFrame(video: String, timeMs: Long, out: String) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(video)
            val bmp = r.getFrameAtTime(timeMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                ?: r.getFrameAtTime(0L)
                ?: throw Exception("Frame tidak ditemukan")
            File(out).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            bmp.recycle()
        } finally {
            r.release()
        }
    }

    // ------------------------------------------------------------------
    // Share ke aplikasi tertentu (WhatsApp / TikTok / Instagram) atau chooser
    // ------------------------------------------------------------------
    private fun share(pathOrUri: String, mime: String, pkg: String?): String {
        return try {
            val uri = if (pathOrUri.startsWith("content://")) {
                Uri.parse(pathOrUri)
            } else {
                FileProvider.getUriForFile(this, "$packageName.fileprovider", File(pathOrUri))
            }
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (pkg != null) {
                send.setPackage(pkg)
                startActivity(send)
            } else {
                startActivity(Intent.createChooser(send, "Bagikan"))
            }
            "ok"
        } catch (e: Exception) {
            "not_installed"
        }
    }
}
